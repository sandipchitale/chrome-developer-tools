chrome.app.runtime.onLaunched.addListener(function() {
    chrome.app.window.create('inspectorwrapper.html', {
        'width' : 900,
        'height' : 700
    });
});