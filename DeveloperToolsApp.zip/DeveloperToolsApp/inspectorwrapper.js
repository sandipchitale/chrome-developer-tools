window.onresize = doLayout;

onload = function() {
    doLayout();
    var info = document.querySelector("#info");
    var webview = document.querySelector('webview');
    var port = document.querySelector("#port");
    var urlport = document.querySelector("#urlport");
    var reconnect = document.querySelector("#reconnect");
    
    port.onchange = function() {
        urlport.textContent = port.value;
        webview.src = "http://localhost:" + port.value;
    }
    
    reconnect.onclick = function() {
        webview.src = "http://localhost:" + port.value;
    }
    
    info.onclick = function() {
        window.open("https://developers.google.com/chrome-developer-tools/docs/contributing", "info", "width=700,height=800");
    }
}

function doLayout() {
    var webview = document.querySelector('webview');
    var windowWidth = document.documentElement.clientWidth;
    var windowHeight = document.documentElement.clientHeight;
    var webviewWidth = windowWidth;
    var webviewHeight = windowHeight;

    webview.style.width = webviewWidth + 'px';
    webview.style.height = webviewHeight + 'px';
}